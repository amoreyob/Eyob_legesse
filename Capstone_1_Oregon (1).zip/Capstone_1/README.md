# Capstone 1: Oregon Online Sales

Eyob Legesse · Year Up United DATA · Emporium fictional sample business

**Working territory:** Oregon online sales. This choice has not been confirmed by the instructor and may change.

This project studies revenue, transaction volume, product categories and online destination-state performance using the supplied `sample_sales` database.

## Main findings

| Measure | Result |
|---|---:|
| Data coverage | 2022-01-01 through 2025-12-31 |
| Oregon online revenue | $7,646,700.17 |
| Oregon transaction rows | 18,504 |
| Average transaction amount | $413.25 |
| Online destination-state rank | 3 of 29 |
| Share of online revenue | 11.2% |
| West region revenue, both channels | $74,417,459.27 |
| Oregon share of West revenue | 10.3% |

## Annual revenue

| Year | Revenue | Transactions |
|---|---:|---:|
| 2022 | $2,500,108.97 | 6,406 |
| 2023 | $2,236,753.75 | 5,362 |
| 2024 | $2,286,601.68 | 5,410 |
| 2025 | $623,235.77 | 1,326 |

## Category performance

| Category | Revenue | Share |
|---|---:|---:|
| Technology & Accessories | $3,654,893.37 | 47.8% |
| Textbooks | $2,033,514.02 | 26.6% |
| Books (General) | $1,090,205.67 | 14.3% |
| Apparel and Merchandise | $457,957.25 | 6.0% |
| Art Supplies | $320,740.91 | 4.2% |
| Stationery and Supplies | $89,388.95 | 1.2% |

## Recommendation

First check the completeness of the 2025 records and investigate the decline in Oregon online transactions. Revenue fell 72.7% and transactions fell 75.5% from 2024 to 2025, while average transaction amount rose 11.2%. If reporting is complete, test a small Technology & Accessories campaign to rebuild transaction volume. This category generated $3,654,893.37, or 47.8% of Oregon's four-year revenue. Measure transaction count, revenue and average transaction amount during the pilot. Obtain margin and return data before expanding it. The sales table alone cannot establish the reason for the decline or the most profitable category.

## What each analysis question uses

1. Total revenue and dates: `data/01_overall_summary.csv`.
2. Revenue by year and month: `data/02_monthly_revenue.csv`.
3. Territory and region comparison: `data/03_region_comparison.csv`.
4. Monthly counts and average amounts by category: `data/04_monthly_category.csv`.
5. Online state ranking: `data/05_state_ranking.csv`.
6. Recommendation evidence: `data/06_quarter_category_evidence.csv` and `data/quarterly_summary.csv`.

## Project files

- `legesse_sales_analysis.sql`: commented MySQL study reference for the six questions.
- `legesse_territory_chart.xlsx`: editable analysis workbook and ordinary Excel charts. **A native PivotChart still needs to be created in Excel.**
- `data/`: query result CSVs, plus the Oregon transaction-level extract.
- `START_HERE.md`: the remaining steps and submission checklist.
- `guides/presentation_notes.md`: timing and speaking notes for both presentations.
- `guides/peer_review_template.md`: the required structure for each of four reviews.
- `guides/method_and_checks.md`: scope choices, source details and verification.

## Recording

**Not recorded yet. Replace this sentence with a shareable link to the 10-minute video.**

## Method and assistance

One `Online_Sales` row is counted as one transaction because the source has no order identifier. Sales amounts are in USD. Category analysis joins through the product and category keys.

The supplied Management table assigns `Online Sales` to `West`. The regional comparison includes all online destination states and Colorado in-store sales. Online Sales has two manager rows, so it is not joined directly to each transaction. The state ranking is a broader online comparison for a single-state territory.

This is an AI-assisted learning draft. The supplied course file requires independently written submitted SQL queries. The SQL reference, workbook and notes should support learning and checking, with assistance acknowledged as required by the course. Rewrite the submitted queries from your understanding and run them in MySQL before presenting them as your work.

CSV results were checked in an isolated SQLite inspection copy of the supplied dump and reconciled using exact integer-cent calculations. They have not been run on the student's MySQL server. A native Excel PivotChart, the recording, GitHub publication, live presentation and peer reviews are still outstanding.
