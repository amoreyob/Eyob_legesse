# Method and verification

## Source

- Supplied file: `647144sample_sales_all.sql`.
- SHA-256: `025012e1268f3256a14358bc44e0e6138f4e29e7ad53f1765c604c7fdeef0767`.
- The dump creates 8 tables. A case-insensitive inspection copy includes both the uppercase `Online_Sales` inserts and the one lowercase `online_sales` insert.
- Query output CSVs were generated from an isolated SQLite copy after translating the database-creation and auto-increment syntax. MySQL-style YEAR, MONTH and DATE_FORMAT were supplied as equivalent inspection functions.
- **MySQL execution and desktop Excel behavior have not been verified on the student's computer.**

## Definitions

| Item | Definition |
|---|---|
| Territory | Rows of Online_Sales with ShiptoState = Oregon |
| Revenue | Sum of SalesTotal in USD |
| Transaction | One source table row; no order-level identifier is supplied |
| Average transaction amount | Revenue divided by transaction rows |
| Date coverage | Earliest through latest transaction date present; dates alone do not prove complete reporting |
| Regional scope | Management assigns Online Sales to West; combine all online sales with West in-store sales, which are Colorado in this file |
| State ranking | All online destination states ranked by total revenue; broader context for the single-state Oregon territory |
| Next-quarter scope | Quarter following the last supplied period, Q1 2026; no actual 2026 data or forecast model is provided |

The original file has two `Management` records with State = Online Sales. Directly joining either online or all-channel revenue to both would double-count it. Online revenue is summed once. In-store region membership uses a distinct state set.

The regional scope and online peer-ranking interpretation should be explained to the instructor because the project wording also permits multi-state online territories. There are no Oregon physical stores in Store_Locations.

## Completed data checks

- All 18,504 Oregon rows survive the product/category joins with no missing or duplicated rows.
- Transaction-level amounts were summed independently as integer cents: $7,646,700.17.
- All 48 monthly groups reconcile to that amount and transaction count.
- All monthly/category groups reconcile to the same amount and count.
- The Oregon row in the 29-state online ranking reconciles to that amount.
- West total equals its two non-overlapping channel components: $68,004,827.05 online plus $6,412,632.22 in-store = $74,417,459.27.
- Workbook formulas were checked against these independent controls. Charts are editable, ordinary Excel charts. A native PivotChart is intentionally marked as an outstanding Excel step.

## Interpretation limits

The source is a fictional sample business, not current market data. The 2025 decline is visible in the supplied records but the file cannot establish its cause. It contains no order ID, quantities, costs, marketing spend or profit margin, so do not label the row average as unit price or order value, calculate conversion rates, or claim the highest-revenue category is the most profitable.

Keep the working territory and regional definition visible. If Nigel changes either, rerun and rebuild the analysis rather than relabeling these Oregon results.
