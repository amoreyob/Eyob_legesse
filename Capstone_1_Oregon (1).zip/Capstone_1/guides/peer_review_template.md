# Peer review worksheet

Complete this only after watching each assigned classmate's actual live presentation and recording and inspecting their SQL, Excel and repository. No classmate's work has been reviewed in this package.

Make **four separate Teams posts**, one for each assigned classmate. Tag that person at the top. Each post needs all six headings and at least two specific comments under each heading: **12 comments per review, 48 across four reviews**. Include strengths and at least one constructive suggestion. Keep a separate question from your viewing notes ready when helpful.

Copy this structure for each person and replace every bracketed prompt with an observation about the actual project:

@[Classmate]

## 1. In-Class Presentation

- I liked how you explained [specific result or method] because [why it helped].
- One thing that could make [specific part] clearer is [concrete suggestion and reason].

## 2. Video Presentation

- Your explanation of [specific query or finding, with timestamp if useful] helped me understand [reason].
- I would have liked to see [specific evidence or demonstration] when you discussed [specific claim].

## 3. SQL Script

- In the query for [question], your use of [specific SQL clause or join] worked well because [reason].
- For [specific query], consider [specific improvement] so that [expected benefit].

## 4. Excel / PivotChart

- The chart showing [specific comparison] made [specific pattern] easy to see because [reason].
- Changing [specific label, grouping, filter or formatting] could improve the chart by [reason].

## 5. GitHub Repository

- The way you organized [actual folder, file or README section] helped me find [specific material].
- Adding or clarifying [actual missing or unclear detail] would help a reviewer [specific benefit].

## 6. Overall

- Your recommendation to [actual recommendation] made sense because [specific supporting evidence].
- One change that could strengthen the project is [specific, constructive action and reason].

Before posting, verify that every comment describes something actually observed, none of the prompts remain, all six headings have two comments, and the classmate is tagged. Check feedback you receive on your own project afterward.
