# Presentation notes

Use these notes after you have run and understood your own queries, created the native PivotChart and checked your results. Personalize the wording. The outline includes screen demonstrations, so rehearse with a timer rather than reading continuously.

## 10-minute recording

### 0:00–0:45 — Introduce the business question

“Hi, my name is Eyob Legesse. This project looks at Oregon online sales for Emporium, a fictional student bookstore business. My goal is to understand revenue, monthly performance, product categories and where sales attention could help next quarter.”

Show the repository README and identify the territory. Say that Oregon is the working selection if the instructor has not confirmed it.

### 0:45–1:30 — Explain the data and method

Show the source tables in MySQL. Explain that Online_Sales contains sales amounts, dates, products and destination states. Products links each product number to a category ID. Inventory_Categories gives the category name.

“I count each sales row as one transaction because there is no separate order ID. I filter the online table to Oregon. For category analysis, I join it to Products and Inventory_Categories.”

Point to the actual WHERE and JOIN clauses in your own query. Explain the join keys in your own words.

### 1:30–2:30 — Question 1: total revenue and coverage

Run your first query and show the result.

“The data covers January 1, 2022 through December 31, 2025. Oregon online revenue totals $7,646,700.17, from 18,504 transaction rows. The average transaction amount is $413.25. SUM gives the revenue, MIN and MAX give the dates, and COUNT gives the number of rows.”

Mention that the presence of a first and last date does not by itself prove every source record was captured.

### 2:30–3:45 — Question 2: monthly and annual revenue

Show the monthly query and its year/month grouping, then open the Excel PivotChart you created.

“I group by both year and month so that the same month in different years stays separate. Annual revenue was about $2.50 million in 2022, $2.24 million in 2023, $2.29 million in 2024 and $623 thousand in 2025.”

Use the PivotChart to compare matching months across the four years. Briefly filter to one year, explain the change, then restore all years. Point out one actual monthly difference you can see rather than guessing a seasonal explanation.

### 3:45–4:45 — Question 3: regional comparison

Show your comparison query and results.

“In this dataset, Management places the online-sales business in West. West also has Colorado in-store sales. I use that business definition rather than assigning every online shipment to its geographic region. West revenue is $74,417,459.27. Oregon online sales contribute about 10.3% of that total.”

“There are two manager rows for Online Sales. I avoid directly joining both to the transaction table, because that would count online sales twice.”

Explain that Oregon is included in the regional total and the comparison rows should not be added together.

### 4:45–6:00 — Question 4: monthly counts and average amounts by category

Run the monthly-category query. Pick one visible month and category, read its count and average, and explain what they mean.

“The category query joins three tables. It shows transaction count, revenue and average transaction amount for each month and category. Across the full period, Technology & Accessories accounts for $3,654,893.37, or 47.8% of Oregon revenue. Textbooks is the next largest category.”

Show the Category data sheet. Explain that the average is revenue divided by transaction count, and that averages from separate months should not be averaged without accounting for their counts.

### 6:00–7:00 — Question 5: online state ranking

Show the state-ranking query and the Oregon row.

“Oregon is a single-state online territory and has no physical store in this dataset. To put its performance in context, I compare all online destination states. Oregon ranks third of 29, behind California and Washington. Oregon contributes about 11.2% of all online revenue.”

Explain that the ranking uses total revenue, not average transaction amount, and uses ORDER BY revenue descending.

### 7:00–8:30 — Question 6: recommendation and limits

“My first recommendation is to check the completeness of the 2025 records and understand the decline. From 2024 to 2025, Oregon revenue fell 72.7% and transaction count fell 75.5%. Average transaction amount rose 11.2%, so the supplied figures point to transaction volume as the main issue to investigate.”

“If reporting is complete, I would test a small Technology & Accessories campaign to rebuild transactions. It is the largest revenue category, but I would also obtain cost and return information before expanding the campaign. High revenue does not tell us profit.”

“I would track transactions, revenue and average transaction amount during the pilot. The data does not tell us why sales fell, so I would not claim a cause.”

Explain that a recommendation for the quarter immediately after this dataset concerns Q1 2026. It is a training scenario, and there are no actual 2026 sales in the supplied file.

### 8:30–9:30 — Demonstrate the deliverables

Show your own saved SQL, your CSV export, the native Excel PivotChart and the GitHub README. Briefly explain the path from query result to CSV to PivotChart. Show the files in the repository after they are actually published.

### 9:30–10:00 — Close

“The main findings are Oregon's $7,646,700.17 revenue, its third-place online state rank and the sharp 2025 transaction decline. My recommendation is to verify reporting first and then test a focused campaign with clear measures. Thank you.”

Stop near 10 minutes. Add the actual recording link to README.md, verify access, commit and push.

## 5-minute live presentation

Keep MySQL, the Excel PivotChart and the README open before your turn.

| Time | Show | Main point |
|---|---|---|
| 0:00–0:35 | README overview | Oregon online sales; 2022–2025; fictional business |
| 0:35–1:15 | Overall query result | $7,646,700.17, 18,504 rows, $413.25 average |
| 1:15–2:15 | Native monthly PivotChart | Four years; compare matching months and identify the 2025 decline |
| 2:15–3:10 | Category results and online ranking | Technology & Accessories 47.8% of revenue; Oregon 3 of 29 |
| 3:10–3:40 | Region comparison | Oregon 10.3% of database-defined West revenue |
| 3:40–4:35 | Recommendation | Verify 2025 reporting; if complete, test a focused campaign and measure transactions |
| 4:35–5:00 | Close | State the main finding and invite a question |

## Questions to rehearse

- Why did you use Online_Sales instead of Store_Sales? — Oregon has online sales and no physical store in Store_Locations.
- What does one transaction mean? — One source row; a separate order ID is not supplied.
- Why group by year and month? — Month alone would combine the same month across multiple years.
- Why not average the monthly averages? — Months have different transaction counts. Use total revenue divided by total transactions.
- Why is the regional comparison called West? — Management assigns the online business to West. The report states that assumption explicitly.
- Why not join Management directly? — There are two Online Sales manager rows, which would duplicate online revenue.
- Does high revenue mean high profit? — No. Costs and profit margin are not supplied.
- Why did revenue decline? — The records show the decline but do not establish the cause.
