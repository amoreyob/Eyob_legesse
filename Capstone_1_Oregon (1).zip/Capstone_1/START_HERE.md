# Start here

Your working territory is **Oregon online sales**. The corrected full database count is **18,504**, not the earlier quick-scan count of 18,224. One insert block uses lowercase `online_sales`, so the quick text scan missed it.

The material here is a learning draft. The course requires you to write your own submitted SQL. Use the commented reference to understand and rebuild each answer, then verify it in MySQL.

The ZIP also includes the original database file in the separate `source_database` folder. That folder does not need to be copied into your GitHub repository.

## 1. Load and check MySQL

1. Open MySQL Workbench and connect to your local server.
2. If `sample_sales` is already loaded, do not rerun the source dump. If it is not loaded, open the original `647144sample_sales_all.sql` in the SQL editor and execute it. The source dump recreates `sample_sales`, replacing any existing database with that name.
3. Open a new query tab and run:

```sql
-- Learning Note: Select the database and check its tables.
USE sample_sales;
SHOW TABLES;
```

There should be 8 tables. The source has 125,565 online rows across all states and 335,129 in-store rows. On a case-sensitive MySQL server, the source's one lowercase `INSERT INTO online_sales` must match `Online_Sales`; Windows installations commonly use case-insensitive table names.

4. Work through the six numbered sections in `legesse_sales_analysis.sql`. Write and save your own version with explanations you understand. Highlight one section and use the execute-selection control. Check its result against the corresponding CSV.
5. Export your own question 2 result from MySQL as a CSV. Compare it with `data/02_monthly_revenue.csv`: 48 monthly rows, total $7,646,700.17, and 18,504 transaction rows in total.

Official instructions: [MySQL query toolbar](https://dev.mysql.com/doc/workbench/en/wb-sql-editor-toolbar.html).

## 2. Finish the required native PivotChart

The workbook already has ordinary editable charts and prepared data. Those charts do not satisfy a requirement specifically calling for a PivotChart.

In desktop Excel for Windows:

1. Open `legesse_territory_chart.xlsx` and choose **Monthly data**.
2. Click a cell inside the blue monthly table `OregonMonthly`.
3. Choose **Insert > PivotChart**, choose **New Worksheet**, then **OK**.
4. Arrange these fields:

| PivotChart area | Field |
|---|---|
| Axis / Rows | Month |
| Legend / Columns | Year |
| Values | Revenue, summarized by **Sum** |

5. Change the chart type to **Line**. Sort Month ascending, so 1 is January and 12 is December.
6. Title it **Oregon monthly online revenue by year (USD)**. Format the revenue axis as currency.
7. Rename the new worksheet **Monthly PivotChart**, save the workbook, and verify all 4 years appear.
8. Change the Year filter once and confirm that the chart responds. Restore all years and save.

If using Excel in a browser, first insert a PivotTable from the monthly table, arrange the fields above, then insert a chart from that PivotTable.

Official instructions: [Microsoft: create a PivotChart](https://support.microsoft.com/en-us/excel/get-started/create-a-pivotchart).

## 3. Put the project in GitHub

The required repository name is **Capstone_1**. These files have not been uploaded to GitHub.

1. Create `Capstone_1` under your current GitHub account and initialize it with a README. Use the visibility/access settings required for your instructor and classmates to review it. Copy its HTTPS clone URL from the **Code** menu.
2. Open Git Bash. Create the class folder if needed, then clone the new repository:

```bash
mkdir -p ~/Documents/DATA_Labs
cd ~/Documents/DATA_Labs
git clone PASTE_YOUR_REPOSITORY_HTTPS_URL_HERE
cd Capstone_1
```

Replace the URL placeholder with the actual HTTPS URL before running the clone command. If this repository is already cloned, open its existing folder instead of cloning over it.

3. Extract this package, then copy the **contents** of its `Capstone_1` folder into your cloned folder. Replace the initial README with this README after reviewing and personalizing it. Include your own SQL and the workbook with the native PivotChart.
4. From the cloned folder, commit real work:

```bash
git status
git add .
git commit -m "Add Oregon sales analysis draft and workbook"
git push
```

5. Make another meaningful commit when you complete your next day's work. Today's commit cannot supply earlier daily progress. If illness prevented earlier commits, explain that to Nigel; do not alter commit dates.
6. Record your video, paste its actual shareable link into README.md, then commit and push that update.
7. Open your repository on GitHub and verify the SQL, Excel file, CSV and recording link are visible to the intended reviewers. Post the actual repository link in the class thread requested by the instructor.

Official instructions: [Repository quickstart](https://docs.github.com/en/repositories/creating-and-managing-repositories/quickstart-for-repositories) and [cloning](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository).

## 4. Record and present

Use `guides/presentation_notes.md`. A large slide deck is not required. Share MySQL for the queries, Excel for the PivotChart, and the README for your conclusion.

- Record your own **10-minute video** and add its link to the README.
- Practice the separate **5-minute live presentation**.
- Use the notes as prompts after doing the work. Do not say you ran a query or built a feature until you have done it.

## Submission checklist

The written deadline is **Friday at 8:30 a.m.** If the current capstone is due this week, that is November 6, 2026, Eastern time. Follow any later instructor update or approved illness accommodation.

- [ ] Oregon territory declared; check for instructor changes.
- [ ] Your independently written `legesse_sales_analysis.sql` covers all six questions.
- [ ] Queries run in MySQL and results verified.
- [ ] Your CSV exported from a query result.
- [ ] `legesse_territory_chart.xlsx` includes a native PivotChart.
- [ ] `Capstone_1` published on GitHub with a short README.
- [ ] Actual daily progress committed, with any illness-related gap explained.
- [ ] 10-minute recording created and linked in the README.
- [ ] Repository and recording access checked.
- [ ] GitHub link posted in the requested class thread.
- [ ] 5-minute live presentation rehearsed and delivered.
- [ ] Four assigned peer reviews completed after viewing the actual projects.

The 20 appendix questions and extra bonus chart are optional and are not included in this core package. Meet the core requirements first.
