-- Your independent capstone workspace: Oregon online sales.
-- Learning Note: Write your own queries under each question. Use the reference
-- only to understand syntax and check your reasoning. Run each query in MySQL.
USE sample_sales;

-- 1. What are Oregon online revenue, start date and end date?
-- Your query:

-- 2. What is Oregon online revenue by year and month?
-- Your query:

-- 3. How does Oregon online revenue compare with the database-defined West region?
-- Your query and explanation of regional scope:

-- 4. What are monthly transaction counts and average amounts by product category?
-- Your query:

-- 5. How does Oregon rank among online destination states?
-- Your query and explanation of the single-state scope:

-- 6. Where should sales attention focus next quarter, and why?
-- Your supporting query and recommendation comment:
